SWeeManager

Cara penggunaan:
1. Pastikan root directory adalah SUBCO/For Ast/
2. Pastikan folder di dalam tiap matakuliah terdapat folder ReadMe
3. Untuk folder tiap asisten pastikan terdapat angkatannya juga (Ex. SW16-2, LC000)
4. Folder di atas kode matakuliah yang dipilih sudah auto mendapatkan permission ke Employee
5. Bila ada saran atau error silahkan hubungin SW16-2
